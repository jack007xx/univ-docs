This devkits directory contains development kit baseline example designs.

HOW TO SETUP PIN ASSIGNMENTS
1) Bring up the Tcl Console panel in Quartus from the View menu --> Utility Windows.
2) Type command 'source platform_setup.tcl' in the Tcl console.
3) Type command 'setup_project' in the Tcl console.
   - Running this command will populate all assignments available in the setup_platform.tcl to your project QSF file.

